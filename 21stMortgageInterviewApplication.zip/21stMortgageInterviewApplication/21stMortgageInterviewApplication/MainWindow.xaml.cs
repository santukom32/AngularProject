﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _21stMortgageInterviewApplication
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void largestBtn_Click(object sender, RoutedEventArgs e)
        {
            var inputText = userInputTextBox.Text.Split(",");
            var largest = inputText.OrderByDescending(itm => Convert.ToInt32(string.IsNullOrEmpty(itm)?"0":itm)).First();
            resultTextBox.Text = largest;
        }

        private void oddBtn_Click(object sender, RoutedEventArgs e)
        {
            var inputText = userInputTextBox.Text.Split(",").Select(itm => Convert.ToInt32(string.IsNullOrEmpty(itm) ? "0" : itm));
            var oddNumbers = inputText.Where(itm => itm % 2 != 0).Select(odd => odd);
            resultTextBox.Text = oddNumbers.AsQueryable().Sum().ToString();

        }

        private void evenBtn_Click(object sender, RoutedEventArgs e)
        {
            var inputText = userInputTextBox.Text.Split(",").Select(itm => Convert.ToInt32(string.IsNullOrEmpty(itm) ? "0" : itm));
            var evenNumbers = inputText.Where(itm => itm % 2 == 0).Select(even => even);
            resultTextBox.Text = evenNumbers.AsQueryable().Sum().ToString();
        }

        private void NumberValidationTextBox(object sender, TextCompositionEventArgs e)
        {
            e.Handled = IsTextAllowed(e.Text);
        }

        private static readonly Regex _regex = new Regex("^(-?[0-9]+[,]?-?[0-9]*|[,]?|[-]?)*$"); 
        private static bool IsTextAllowed(string text)
        {
            return !_regex.IsMatch(text);
        }

        private void TextBoxPasting(object sender, DataObjectPastingEventArgs e)
        {
            if (e.DataObject.GetDataPresent(typeof(String)))
            {
                String text = (String)e.DataObject.GetData(typeof(String));
                if (!IsTextAllowed(text))
                    e.CancelCommand();
            }
            else
                e.CancelCommand();
        }
    }

    public class ValueConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            if (value != null)
            {
                if (System.Convert.ToInt32(value) > 0)
                    return true;
            }
            return false;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            return null;
        }
    }

    public class ViewModel : INotifyPropertyChanged
    {
        private string _text;

        public string Text
        {
            get
            {
                return this._text;
            }
            set
            {
                this._text = value;
                if (null != PropertyChanged)
                {
                    this.PropertyChanged(this, new PropertyChangedEventArgs("Text"));
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }

}
