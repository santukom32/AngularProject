import { Injectable } from '@angular/core';
import { ILoginResult } from './login-result';
import { IUser } from './user';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor() { }

  public login(loginUser: IUser) : ILoginResult{
    return  { loginSuccessful: true };
  }
}
