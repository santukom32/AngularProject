export interface IUser {
    loginName: string;
    password: string;
}